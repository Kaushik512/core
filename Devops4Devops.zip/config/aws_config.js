/*module.exports = {
AKIAIGKHA73UCDNU6DTQ

	access_key : "AKIAI5JPZ6FOH4K3NQXQ",
	secret_key : "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",
	region : "us-east-1"
}*/

/*
module.exports = {

	access_key : "AKIAJFEXRU3MVMRJEBFA",
	secret_key : "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",
	region : "us-west-2"
}
*/

/*var awsSettings = {
	access_key : "AKIAJFEXRU3MVMRJEBFA",
	secret_key : "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",
	region : "us-west-2",
	keyPairName:"devopstest",
	securityGroupId : "sg-c00ee1a5",
	pemFileLocation : "/home/anshul/",
	pemFile:"devopstest-us-west-2.pem",
	instanceUserName:"root"
}*/

var awsSettings = {
	access_key : "AKIAI6TVFFD23LMBJUPA",
	secret_key : "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",
	region : "us-west-2",
	keyPairName:"devopstest",
	securityGroupId : "sg-c00ee1a5",
	pemFileLocation : "/home/anshul/",
	pemFile:"devopstest-us-west-2.pem",
	instanceUserName:"root"
}

/*

var awsSettings = {
	access_key : "AKIAI5JPZ6FOH4K3NQXQ",
	secret_key : "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",
	region : "us-west-2",
	keyPairName:"devopstest",
	securityGroupId : "sg-edc720de",
	pemFileLocation : "/home/anshul/",
	pemFile:"devopstest-us-west-2.pem",
	instanceUserName:"root"
}
*/
module.exports = awsSettings;


