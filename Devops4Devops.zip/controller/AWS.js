var aws = require('../node_modules/aws-sdk');

var opscode = aws.OpsWorks({apiVersion: '2013-02-18'});




//Access Key ID:

//AKIAJSEVHOO6M6YFYX3Q

//Secret Access Key:

//Nr0RmdeCeJC7vbTMQEOiy12GE2vSkAzsl2OKPwbu